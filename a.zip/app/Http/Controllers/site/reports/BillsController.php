<?php

namespace App\Http\Controllers\site\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Bills;

class BillsController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function index()
    {
        $month = \Carbon\Carbon::now()->month;
        $year = \Carbon\Carbon::now()->year;
       
        return view('site/reports/bills/index', [
            'month' => $month,
            'year' => $year,
        ]);
    }

    public function report(Request $request){
        $month = $request->get('month');
        $year = $request->get('year');

        $year_get = $year+543;
        $month_get = Bills::MonthThai((int)$month);

        $date = $year."-".$month;
        $data = Bills::ReportBills($date)->get();

        $count_search = count($data);
       
        return view('site/reports/bills/index', [
            'data' => $data,
            'date_search' => $month."/".$year_get,
            'date_Before' => $date,
            'count_search' => $count_search,
            'date_get' => "เดือน ".$month_get." ".$year_get
        ]);
    }
}
