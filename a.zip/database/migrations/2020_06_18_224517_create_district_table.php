<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDistrictTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('district', function (Blueprint $table) {
            $table->id('DISTRICT_ID');
            $table->string('DISTRICT_CODE');
            $table->string('DISTRICT_NAME');
            $table->integer('AMPHUR_ID');
            $table->integer('PROVINCE_ID');
            $table->integer('GEO_ID');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('district');
    }
}
